﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using CMd5Util;
using PayGat_PC_NET.Action;

namespace PayGat_PC_NET
{
    public partial class ReturnUrl : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            String MemberID = Request.Params["MemberID"];//商户号
            String TerminalID = Request.Params["TerminalID"];//商户终端号		

            String TransID = Request.Params["TransID"];//商户流水号
            String Result = Request.Params["Result"];//支付结果
            String ResultDesc = Request.Params["ResultDesc"];//支付结果描述
            String FactMoney = Request.Params["FactMoney"];//实际成功金额
            String AdditionalInfo = Request.Params["AdditionalInfo"];//订单附加消息	
            String SuccTime = Request.Params["SuccTime"];//支付完成时间
            String Md5Sign = Request.Params["Md5Sign"];//MD5签名宝付返回的

            String Md5key = ConfigurationManager.AppSettings["Md5Key"];//md5密钥（KEY）
            String MARK = "~|~";

            Log.LogWrite("接收返回MD5值：" + Md5Sign);
            String md5 = "MemberID=" + MemberID + MARK + "TerminalID=" + TerminalID + MARK + "TransID=" + TransID + MARK + "Result=" + Result + MARK + "ResultDesc=" + ResultDesc + MARK
        + "FactMoney=" + FactMoney + MARK + "AdditionalInfo=" + AdditionalInfo + MARK + "SuccTime=" + SuccTime
        + MARK + "Md5Sign=" + Md5key;
            Log.LogWrite("本地MD5验签字串:" + md5);//商户在正式环境不要输出此项以免泄漏密钥，只在测试时输出以检查验签失败问题
		

            String WaitSign = CMD5.GetMD5Hash(md5);
            Log.LogWrite("本地MD5验签值:" + WaitSign);

            if (WaitSign.Equals(Md5Sign))
            {
                Log.LogWrite("处理成功返回OK");
                Response.Write("OK");//全部正确了输出OK            
            }
            else {
                Log.LogWrite("本地MD5验签失败！");
                Response.Write("Md5CheckFail");//MD5验签失败	
            }

        }
    }
}