﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using CMd5Util;


namespace PayGat_PC_NET.Action
{
    public partial class Actions : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            String PayID = Request.Params["PayID"];
            String TxnAmt = Request.Params["OrderMoney"];

            Log.LogWrite("支付金额：" + TxnAmt);
            String OrderMoney ="";
            if (!String.IsNullOrEmpty(TxnAmt)){
                OrderMoney = decimal.Round((decimal.Parse(TxnAmt) * 100), 0).ToString();//金额以分为单位
            }else {
                OrderMoney = "0";
            }

            Log.LogWrite("支付金额（转换成分为单位）：" + OrderMoney);

            if (String.IsNullOrEmpty(PayID)){//PayID传空跳转宝付收银台，传功能ID跳转对应的银行		
                PayID = "";
                Log.LogWrite("链接类型：跳转宝付收银台");
            }else{
                Log.LogWrite("链接类型：直链银行");
            }
            String InterfaceVersion = "4.0";
            String KeyType = "1";//加密类型(固定值为1)
            String TransID = GetTransId();//商户订单号（不能重复）
            String TradeDate = DateTime.Now.ToString("yyyyMMddHHmmss");//下单日期		
            String MemberID = ConfigurationManager.AppSettings["MemberId"];//商户号
            String TerminalID = ConfigurationManager.AppSettings["TerminalId"];//终端号
            String ProductName = "商品名称";//商品名称
            String Amount = "1";//商品数量
            String Username = "用户名称";//支付用户名称
            String AdditionalInfo = "附加信息";//订单附加信息
            String PageUrl = ConfigurationManager.AppSettings["PageUrl"];//页面跳转地址
            String ReturnUrl = ConfigurationManager.AppSettings["ReturnUrl"];//服务器底层通知地址
            String NoticeType = ConfigurationManager.AppSettings["NoticeType"];//通知类型	
            String Md5key = ConfigurationManager.AppSettings["Md5Key"];//md5密钥（KEY）
            String MARK = "|";

            String md5 = MemberID + MARK + PayID + MARK + TradeDate + MARK + TransID + MARK + OrderMoney +
                MARK + PageUrl + MARK + ReturnUrl + MARK + NoticeType + MARK + Md5key;//MD5签名格式

            Log.LogWrite("请求（MD5）拼接字串：" + md5);//商户在正式环境不要输出此项以免泄漏密钥，只在测试时输出以检查验签失败问题


            String Signature = CMD5.GetMD5Hash(md5);//计算MD5值
            String payUrl = "https://vgw.baofoo.com/payindex";//请求地址

            String FormString = "<body onload=\"pay.submit()\">" +
                        "正在提交请稍后。。。。。。。。" +
                        "<form method=\"post\" name=\"pay\" id=\"pay\" action=\"" + payUrl + "\">" +
                        "<input name=\"MemberID\" type=\"hidden\" value=\"" + MemberID + "\"/>" +
                        "<input name=\"TerminalID\" type=\"hidden\" value=\"" + TerminalID + "\"/>" +
                        "<input name=\"InterfaceVersion\" type=\"hidden\" value= \"" + InterfaceVersion + "\"/>" +
                        "<input name=\"KeyType\" type=\"hidden\" value= \"" + KeyType + "\"/>" +
                        "<input name=\"PayID\" type=\"hidden\" value= \"" + PayID + "\"/>" +
                        "<input name=\"TradeDate\" type=\"hidden\" value= \"" + TradeDate + "\" />" +
                        "<input name=\"TransID\" type=\"hidden\" value= \"" + TransID + "\" />" +
                        "<input name=\"OrderMoney\" type=\"hidden\" value= \"" + OrderMoney + "\"/>" +
                        "<input name=\"ProductName\" type=\"hidden\" value= \"" + ProductName + "\"/>" +
                        "<input name=\"Amount\" type=\"hidden\" value= \"" + Amount + "\"/>" +
                        "<input name=\"Username\" type=\"hidden\" value= \"" + Username + "\"/>" +
                        "<input name=\"AdditionalInfo\" type=\"hidden\" value= \"" + AdditionalInfo + "\"/>" +
                        "<input name=\"PageUrl\" type=\"hidden\" value= \"" + PageUrl + "\"/>" +
                        "<input name=\"ReturnUrl\" type=\"hidden\" value= \"" + ReturnUrl + "\"/>" +
                        "<input name=\"Signature\" type=\"hidden\" value=\"" + Signature + "\"/>" +
                        "<input name=\"NoticeType\" type=\"hidden\" value= \"" + NoticeType + "\"/>" +
                        "</form></body>";

            Log.LogWrite("提交表单:" + FormString);

            Response.Write(FormString);

        }


        private string GetTransId()
        {
            return "PAYGATID" + GetTimeStamp() + RandomString();
        }

        private string GetTimeStamp()   //获取时间戳
        {
            TimeSpan ts = DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0);
            return Convert.ToInt64(ts.Milliseconds).ToString();
        }

        private string RandomString() //生成四位随机数
        {
            Random rad = new Random();
            int value = rad.Next(1000, 10000);
            return value.ToString();
        }



    }
}