<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
require_once 'init.php';
require_once 'Log.php';

$arr["MemberID"] =$Member_ID;//商户号
$arr["TerminalID"]=$Terminal_ID;//终端号
$arr["PayID"]=isset($_POST["PayID"]) ? $_POST["PayID"] : "";//
$arr["TradeDate"]= return_time();//日期时间
$arr["TransID"]= get_transid();//商户订单号

$Money=isset($_POST["Money"]) ? $_POST["Money"] : "0";//接收金额

$arr["OrderMoney"]=(int)($Money*100);//订单金额(以分为单位)
$arr["InterfaceVersion"]="4.0";
$arr["ProductName"]="产品名称";
$arr["Amount"]="1";//商户数量
$arr["UserName"]="支付用户名称";
$arr["AdditionalInfo"]="附加信息";
$arr["PageUrl"]="http://www.baofoo.com";//页面跳转地址（改成商户自已的地址）
$arr["ReturnUrl"]="http://www.baofoo.com";//服务器通知地址(改成商户自己的接收通知地址。)
$arr["KeyType"]="1";
$arr["NoticeType"]="1";//1：页面通知+异步通知；0：异步通知

$Md5Key = $Md5_Key;//商户钥钥
$MARK = "|";
$Md5String =  $arr["MemberID"].$MARK.$arr["PayID"].$MARK.$arr["TradeDate"].$MARK.$arr["TransID"].$MARK.$arr["OrderMoney"].$MARK.$arr["PageUrl"].$MARK.$arr["ReturnUrl"].$MARK.$arr["NoticeType"].$MARK.$Md5Key;
$arr["Signature"]=  md5($Md5String);//签名字段
Log::LogWirte($Md5String);
$payUrl="https://vgw.baofoo.com/payindex";//测试请求地址

$ReturnString = '<body onLoad="document.actform.submit()">正在处理请稍候............................'
        . '<form  id="actform" name="actform" method="post" action="'.$payUrl.'">'
        . '<input name="MemberID" type="hidden" value="'.$arr["MemberID"].'"/>'          
        . '<input name="TerminalID" type="hidden" value="'.$arr["TerminalID"].'"/>'
        . '<input name="PayID" type="hidden" value="'.$arr["PayID"].'"/>'
        . '<input name="InterfaceVersion" type="hidden" value="'.$arr["InterfaceVersion"].'"/>'
        . '<input name="KeyType" type="hidden"  value="'.$arr["KeyType"].'"/>'
        . '<input name="TradeDate" type="hidden"  value="'.$arr["TradeDate"].'"/>'
        . '<input name="TransID" type="hidden"  value="'.$arr["TransID"].'"/>'
        . '<input name="OrderMoney" type="hidden"  value="'.$arr["OrderMoney"].'"/>'
        . '<input name="ProductName" type="hidden"  value="'.$arr["ProductName"].'"/>'
        . '<input name="Username" type="hidden"  value="'.$arr["UserName"].'"/>'
        . '<input name="AdditionalInfo" type="hidden"  value="'.$arr["AdditionalInfo"].'"/>'
        . '<input name="NoticeType" type="hidden"  value="'.$arr["NoticeType"].'"/>'
        . '<input name="PageUrl" type="hidden"  value="'.$arr["PageUrl"].'"/>'
        . '<input name="ReturnUrl" type="hidden"  value="'.$arr["ReturnUrl"].'"/>'
        . '<input name="Signature" type="hidden"  value="'.$arr["Signature"].'"/>'
        . '</form></body>';

Log::LogWirte($ReturnString);
echo $ReturnString;

die();

function get_transid(){//生成时间戳
return strtotime(date('Y-m-d H:i:s',time()));
}
function rand4(){//生成四位随机数
return rand(1000,9999);
}
function return_time(){//生成时间
return date('YmdHis',time());
}