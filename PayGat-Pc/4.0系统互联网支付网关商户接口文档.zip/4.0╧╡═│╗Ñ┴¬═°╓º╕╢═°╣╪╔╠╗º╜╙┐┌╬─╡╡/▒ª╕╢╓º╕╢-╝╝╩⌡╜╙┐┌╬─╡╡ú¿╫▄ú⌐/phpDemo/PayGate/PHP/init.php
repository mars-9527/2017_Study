<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$Member_ID  ="100000178";//商户号
$Terminal_ID ="10000001";//终端号
$Md5_Key = "abcdefg";//商户钥钥
